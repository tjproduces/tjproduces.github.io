document.getElementById('last-modified').innerHTML = "<p> Last Updated: " + document.lastModified + "</p>"
document.getElementById('current-year').innerHTML = new Date().getFullYear()